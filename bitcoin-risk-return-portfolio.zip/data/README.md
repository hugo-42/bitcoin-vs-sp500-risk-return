# Données

- Ce dépôt inclut un **mini-échantillon** `bitcoin_prices.csv` uniquement pour permettre le Knit.
- Pour vos analyses réelles, **remplacez** ce fichier par un CSV au même format (colonnes `date`, `close`).
- Évitez de versionner de gros CSV dans Git : utilisez des liens vers la source.